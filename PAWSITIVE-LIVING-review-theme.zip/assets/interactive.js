/* ============================================================
   PAWSITIVE.LIVING — Interactive features
   Ritual finder quiz · Product image zoom
   ============================================================ */
(function () {
  'use strict';

  var $ = function (sel, ctx) { return (ctx || document).querySelector(sel); };
  var $$ = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };
  var escapeHtml = function (value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (character) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character];
    });
  };

/* ---------- Ritual finder quiz ---------- */
  $$('[data-quiz]').forEach(function (quiz) {
    var config = JSON.parse($('[data-quiz-config]', quiz).textContent);
    var steps = $$('[data-quiz-step]', quiz);
    var result = $('[data-quiz-result]', quiz);
    var nextBtn = $('[data-quiz-next]', quiz);
    var backBtn = $('[data-quiz-back]', quiz);
    var progress = $('[data-quiz-progress]', quiz);
    var standardResult = $('[data-quiz-standard-result]', result);
    var safetyStop = $('[data-quiz-safety-stop]', result);
    var current = 0;
    var answers = {};

    function showStep(i) {
      steps.forEach(function (s, idx) { s.hidden = idx !== i; });
      result.hidden = true;
      nextBtn.hidden = false;
      backBtn.hidden = i === 0;
      nextBtn.disabled = !answers[i];
      nextBtn.textContent = nextBtn.dataset.label || nextBtn.textContent;
      progress.textContent = i === 0 ? 'Safety check · Step 1 of ' + steps.length : 'Question ' + i + ' of ' + (steps.length - 1);
      current = i;
    }

    function showResult() {
      var needsVetReview = answers[0] === 'pause';
      if (standardResult) standardResult.hidden = needsVetReview;
      if (safetyStop) safetyStop.hidden = !needsVetReview;
      if (needsVetReview) {
        steps.forEach(function (step) { step.hidden = true; });
        result.hidden = false;
        nextBtn.hidden = true;
        backBtn.hidden = true;
        progress.textContent = '';
        return;
      }

      // Ignore the safety answer. Any tie between product scores goes to the bundle.
      var scores = { paw: 0, coat: 0, bundle: 0 };
      Object.keys(answers).forEach(function (key) {
        var value = answers[key];
        if (scores[value] !== undefined) scores[value]++;
      });
      var highest = Math.max(scores.paw, scores.coat, scores.bundle);
      var leaders = Object.keys(scores).filter(function (key) { return scores[key] === highest; });
      var winner = leaders.length === 1 ? leaders[0] : 'bundle';

      var p = config.products[winner];
      var r = config.results[winner];
      $('[data-quiz-result-title]', result).textContent = r.title;
      $('[data-quiz-result-text]', result).textContent = r.text;
      var prodHtml = '';
      if (p && p.url) {
        prodHtml = '<a class="quiz__product-card" href="' + escapeHtml(p.url) + '">' +
          (p.image ? '<img src="' + escapeHtml(p.image) + '" alt="' + escapeHtml(p.title || '') + '" loading="lazy">' : '') +
          '<span class="quiz__product-info"><strong>' + escapeHtml(p.title || '') + '</strong>' +
          (p.price ? '<span>' + escapeHtml(p.price) + '</span>' : '') + '</span></a>';
      }
      $('[data-quiz-result-product]', result).innerHTML = prodHtml;

      steps.forEach(function (s) { s.hidden = true; });
      result.hidden = false;
      nextBtn.hidden = true;
      backBtn.hidden = true;
      progress.textContent = '';
    }

    quiz.addEventListener('change', function (e) {
      if (!e.target.matches('[data-quiz-input]')) return;
      var step = e.target.closest('[data-quiz-step]');
      var idx = steps.indexOf(step);
      answers[idx] = e.target.value;
      if (idx === current) nextBtn.disabled = false;
    });

    nextBtn.addEventListener('click', function () {
      if (current === 0 && answers[0] === 'pause') { showResult(); return; }
      if (current < steps.length - 1) showStep(current + 1);
      else showResult();
    });
    backBtn.addEventListener('click', function () {
      if (current > 0) showStep(current - 1);
    });
    var restart = $('[data-quiz-restart]', quiz);
    if (restart) restart.addEventListener('click', function () {
      answers = {};
      $$('[data-quiz-input]', quiz).forEach(function (input) { input.checked = false; });
      if (standardResult) standardResult.hidden = false;
      if (safetyStop) safetyStop.hidden = true;
      showStep(0);
    });

    if (steps.length) showStep(0);
  });

  /* ---------- Product image zoom (hover) ---------- */
  $$('.product__featured').forEach(function (wrap) {
    var img = wrap.querySelector('img');
    if (!img) return;
    wrap.classList.add('zoomable');
    wrap.addEventListener('mousemove', function (e) {
      var rect = wrap.getBoundingClientRect();
      var x = ((e.clientX - rect.left) / rect.width) * 100;
      var y = ((e.clientY - rect.top) / rect.height) * 100;
      img.style.transformOrigin = x + '% ' + y + '%';
    });
    wrap.addEventListener('mouseenter', function () {
      img.style.transform = 'scale(1.8)';
    });
    wrap.addEventListener('mouseleave', function () {
      img.style.transform = '';
      img.style.transformOrigin = 'center';
    });
  });
})();
