/* ============================================================
   PAWSITIVE.LIVING — Theme interactions
   Cart drawer · Mobile navigation · Accordion · Variants · Qty
   Dependency-free; uses Shopify's native cart AJAX endpoints.
   ============================================================ */
(function () {
  'use strict';

  var $ = function (selector, context) { return (context || document).querySelector(selector); };
  var $$ = function (selector, context) { return Array.prototype.slice.call((context || document).querySelectorAll(selector)); };
  var moneyFormat = (document.body && document.body.dataset.moneyFormat) || '${{amount}}';

  // Respect the visitor's reduced-motion preference for autoplaying hero footage.
  var heroVideo = $('.hero__video');
  if (heroVideo && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    heroVideo.pause();
    heroVideo.removeAttribute('autoplay');
  }

  function formatMoney(cents) {
    var value = Number(cents || 0) / 100;
    function numberWithSeparators(decimals, thousands, decimalPoint) {
      var fixed = value.toFixed(decimals).split('.');
      fixed[0] = fixed[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousands);
      return decimals ? fixed[0] + decimalPoint + fixed[1] : fixed[0];
    }
    var replacements = {
      amount: numberWithSeparators(2, ',', '.'),
      amount_no_decimals: numberWithSeparators(0, ',', '.'),
      amount_with_comma_separator: numberWithSeparators(2, '.', ','),
      amount_no_decimals_with_comma_separator: numberWithSeparators(0, '.', ',')
    };
    return moneyFormat.replace(/\{\{\s*(amount(?:_no_decimals)?(?:_with_comma_separator)?|amount_with_comma_separator|amount_no_decimals_with_comma_separator)\s*\}\}/g, function (token, key) {
      return replacements[key] || token;
    });
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (character) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character];
    });
  }

  /* ---------- Cart drawer ---------- */
  var drawer = $('#CartDrawer');
  var overlay = $('#CartDrawerOverlay');
  var lastFocused = null;
  var cartRequestPending = false;

  function announce(message) {
    var status = $('#CartStatus');
    if (status) status.textContent = message;
  }

  function setBackgroundInert(inert) {
    $$('#MainContent, .site-header, .site-footer').forEach(function (element) {
      if (inert) element.setAttribute('inert', '');
      else element.removeAttribute('inert');
    });
  }

  function openDrawer() {
    if (!drawer) return;
    lastFocused = document.activeElement;
    document.body.classList.add('cart-open');
    drawer.setAttribute('aria-hidden', 'false');
    if (overlay) overlay.setAttribute('aria-hidden', 'false');
    setBackgroundInert(true);
    var closeButton = $('.cart-drawer__close', drawer);
    if (closeButton) closeButton.focus();
  }

  function closeDrawer() {
    if (!drawer) return;
    document.body.classList.remove('cart-open');
    drawer.setAttribute('aria-hidden', 'true');
    if (overlay) overlay.setAttribute('aria-hidden', 'true');
    setBackgroundInert(false);
    if (lastFocused && typeof lastFocused.focus === 'function') lastFocused.focus();
  }

  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Tab' || !drawer || !document.body.classList.contains('cart-open')) return;
    var focusable = $$('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])', drawer)
      .filter(function (element) { return element.offsetParent !== null; });
    if (!focusable.length) return;
    var first = focusable[0];
    var last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });

  function cartCount(cart) {
    return (cart.items || []).reduce(function (total, item) { return total + item.quantity; }, 0);
  }

  function renderCart(cart) {
    var itemsElement = $('#CartDrawerItems');
    var footElement = $('#CartDrawerFoot');
    var count = cartCount(cart);
    $$('[data-cart-count]').forEach(function (element) {
      element.textContent = count;
      if (count === 0) element.setAttribute('hidden', '');
      else element.removeAttribute('hidden');
    });

    if (!itemsElement) return;
    if (!cart.items || cart.items.length === 0) {
      itemsElement.innerHTML = '<div class="cart-drawer__empty"><p>Your cart is empty.</p><p style="margin-top:1rem"><a class="btn btn--secondary" href="' + escapeHtml((drawer && drawer.dataset.shopUrl) || '/collections/all') + '">Explore the collection</a></p></div>';
      if (footElement) footElement.style.display = 'none';
      var emptyProgress = $('#ShipProgress');
      if (emptyProgress) emptyProgress.style.display = 'none';
      return;
    }

    if (footElement) footElement.style.display = '';
    itemsElement.innerHTML = cart.items.map(function (item) {
      var image = item.image ? '<img src="' + escapeHtml(item.image.replace(/(\.[a-z]+)(?:\?.*)?$/i, '_160x$1')) + '" alt="' + escapeHtml(item.product_title) + '" loading="lazy" width="84" height="104">' : '';
      var variant = item.variant_title && item.variant_title !== 'Default Title' ? '<p class="cart-item__variant">' + escapeHtml(item.variant_title) + '</p>' : '';
      return '<div class="cart-item" data-key="' + escapeHtml(item.key) + '">' +
        '<div class="cart-item__media">' + image + '</div>' +
        '<div><p class="cart-item__title"><a href="' + escapeHtml(item.url) + '">' + escapeHtml(item.product_title) + '</a></p>' + variant +
        '<div class="cart-item__row"><span class="cart-item__qty">' +
        '<button type="button" data-qty="minus" aria-label="Decrease quantity">−</button>' +
        '<output aria-live="polite">' + item.quantity + '</output>' +
        '<button type="button" data-qty="plus" aria-label="Increase quantity">+</button></span>' +
        '<span class="cart-item__price">' + formatMoney(item.final_line_price) + '</span></div>' +
        '<button type="button" class="cart-item__remove" data-remove>Remove</button></div></div>';
    }).join('');

    var subtotal = $('#CartSubtotal');
    if (subtotal) subtotal.textContent = formatMoney(cart.total_price);
    var threshold = drawer ? parseInt(drawer.dataset.freeShip || '0', 10) : 0;
    var progress = $('#ShipProgress');
    if (progress && threshold > 0) {
      progress.style.display = '';
      progress.hidden = false;
      var label = $('#ShipProgressLabel');
      var fill = $('#ShipProgressFill');
      var percent = Math.min(100, Math.round((cart.total_price / threshold) * 100));
      if (fill) fill.style.width = percent + '%';
      var bar = $('.ship-progress__bar');
      if (bar) bar.setAttribute('aria-valuenow', percent);
      if (label) label.textContent = cart.total_price >= threshold ? 'Your order ships free.' : 'You are ' + formatMoney(threshold - cart.total_price) + ' away from free shipping.';
    } else if (progress) {
      progress.hidden = true;
      progress.style.display = 'none';
    }
  }

  function requestJson(url, options) {
    return fetch(url, options || {}).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (body) {
        if (!response.ok) throw new Error(body.description || body.message || 'The cart could not be updated. Please try again.');
        return body;
      });
    });
  }

  function refreshCart(openAfter) {
    if (cartRequestPending) return Promise.resolve();
    cartRequestPending = true;
    return requestJson('/cart.js', { headers: { Accept: 'application/json' } })
      .then(function (cart) {
        renderCart(cart);
        if (openAfter) openDrawer();
        document.dispatchEvent(new CustomEvent('cart:updated', { detail: cart }));
        return cart;
      })
      .catch(function (error) { announce(error.message); throw error; })
      .finally(function () { cartRequestPending = false; });
  }

  function addToCart(formData, openAfter) {
    return requestJson('/cart/add.js', { method: 'POST', headers: { Accept: 'application/json' }, body: formData })
      .then(function () { return requestJson('/cart.js', { headers: { Accept: 'application/json' } }); })
      .then(function (cart) {
        renderCart(cart);
        if (openAfter !== false) openDrawer();
        document.dispatchEvent(new CustomEvent('cart:updated', { detail: cart }));
        return cart;
      });
  }

  document.addEventListener('submit', function (event) {
    var form = event.target;
    if (!form.matches || !form.matches('[data-product-form]')) return;
    event.preventDefault();
    var button = $('[data-add-to-cart]', form);
    var originalText = button ? button.textContent : '';
    var errorElement = $('.form-status--error', form);
    if (errorElement) { errorElement.hidden = true; errorElement.textContent = ''; }
    if (button) { button.disabled = true; button.textContent = button.dataset.addingText || 'Adding…'; }

    addToCart(new FormData(form), true).then(function () {
      var root = form.closest('[data-product-root]');
      var titleElement = root ? $('.product__title', root) : null;
      var quantityInput = form.querySelector('input[name="quantity"]');
      var quantity = quantityInput ? (parseInt(quantityInput.value, 10) || 1) : 1;
      announce((titleElement ? titleElement.textContent.trim() : 'Product') + ' added to your cart' + (quantity > 1 ? ' (' + quantity + ').' : '.'));
    }).catch(function (error) {
      if (errorElement) { errorElement.textContent = error.message; errorElement.hidden = false; }
      else announce(error.message);
    }).finally(function () {
      if (button) { button.disabled = false; button.textContent = originalText; }
    });
  });

  document.addEventListener('click', function (event) {
    var stickyButton = event.target.closest('[data-sticky-add]');
    if (!stickyButton) return;
    var root = stickyButton.closest('[data-product-root]');
    var form = root ? $('[data-product-form]', root) : document.getElementById('ProductForm');
    if (form && typeof form.requestSubmit === 'function') form.requestSubmit();
    else if (form) form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
  });

  if (drawer) {
    drawer.addEventListener('click', function (event) {
      if (event.target.closest('[data-cart-close]')) { closeDrawer(); return; }
      var itemElement = event.target.closest('[data-key]');
      if (!itemElement) return;
      var quantityButton = event.target.closest('[data-qty]');
      var removeButton = event.target.closest('[data-remove]');
      if (!quantityButton && !removeButton) return;
      event.preventDefault();
      if (itemElement.dataset.busy === '1') return;
      var output = $('output', itemElement);
      var quantity = output ? parseInt(output.textContent, 10) || 1 : 1;
      var nextQuantity = removeButton ? 0 : (quantityButton.dataset.qty === 'plus' ? quantity + 1 : Math.max(0, quantity - 1));
      var titleElement = $('.cart-item__title', itemElement);
      var title = titleElement ? titleElement.textContent.trim() : 'Item';
      itemElement.dataset.busy = '1';
      $$('button', itemElement).forEach(function (button) { button.disabled = true; });
      requestJson('/cart/change.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ id: itemElement.dataset.key, quantity: nextQuantity })
      }).then(function (cart) {
        renderCart(cart);
        announce(nextQuantity === 0 ? title + ' removed from your cart.' : title + ' quantity updated to ' + nextQuantity + '.');
      }).catch(function (error) {
        announce(error.message);
        $$('button', itemElement).forEach(function (button) { button.disabled = false; });
      }).finally(function () { delete itemElement.dataset.busy; });
    });
  }

  if (overlay) overlay.addEventListener('click', closeDrawer);
  document.addEventListener('keydown', function (event) { if (event.key === 'Escape') { closeDrawer(); closeMenu(); } });
  document.addEventListener('click', function (event) {
    var cartButton = event.target.closest('[data-open-cart]');
    if (!cartButton) return;
    event.preventDefault();
    refreshCart(true).catch(function () { openDrawer(); });
  });

  /* ---------- Quantity controls ---------- */
  document.addEventListener('click', function (event) {
    var button = event.target.closest('[data-qty-minus], [data-qty-plus]');
    if (!button) return;
    var wrapper = button.closest('.qty');
    var input = wrapper ? wrapper.querySelector('input[type="number"]') : null;
    if (!input) return;
    var current = parseInt(input.value, 10);
    if (isNaN(current) || current < 1) current = 1;
    input.value = button.hasAttribute('data-qty-plus') ? current + 1 : Math.max(1, current - 1);
    input.dispatchEvent(new Event('change', { bubbles: true }));
  });
  document.addEventListener('change', function (event) {
    if (event.target.matches && event.target.matches('.qty input[type="number"]')) {
      var value = parseInt(event.target.value, 10);
      if (isNaN(value) || value < 1) event.target.value = 1;
    }
  });

  /* ---------- Mobile menu ---------- */
  var menuButton = $('#MobileMenuBtn');
  var mobileNav = $('#MobileNav');
  function closeMenu() {
    if (!mobileNav || !menuButton) return;
    mobileNav.classList.remove('is-open');
    menuButton.setAttribute('aria-expanded', 'false');
  }
  if (menuButton && mobileNav) {
    menuButton.addEventListener('click', function () {
      var isOpen = mobileNav.classList.toggle('is-open');
      menuButton.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      if (isOpen) { var firstLink = $('a', mobileNav); if (firstLink) firstLink.focus(); }
      else menuButton.focus();
    });
    mobileNav.addEventListener('click', function (event) { if (event.target.closest('a')) closeMenu(); });
  }

  /* ---------- Accordions ---------- */
  $$('[data-accordion]').forEach(function (accordion) {
    var buttons = $$('.accordion__btn', accordion);
    buttons.forEach(function (button) {
      var panel = document.getElementById(button.getAttribute('aria-controls'));
      button.addEventListener('click', function () {
        var wasExpanded = button.getAttribute('aria-expanded') === 'true';
        buttons.forEach(function (otherButton) {
          otherButton.setAttribute('aria-expanded', 'false');
          var otherPanel = document.getElementById(otherButton.getAttribute('aria-controls'));
          if (otherPanel) otherPanel.style.maxHeight = null;
        });
        if (!wasExpanded) {
          button.setAttribute('aria-expanded', 'true');
          if (panel) panel.style.maxHeight = panel.scrollHeight + 'px';
        }
      });
    });
  });

  /* ---------- Product variant selection ---------- */
  $$('[data-product-json]').forEach(function (scriptElement) {
    var root = scriptElement.closest('[data-product-root]');
    if (!root) return;
    var variants;
    try { variants = JSON.parse(scriptElement.textContent); }
    catch (error) { console.error('PAWSITIVE.LIVING: product variant data is invalid.', error); return; }
    var form = $('[data-product-form]', root);
    if (!form) return;
    var variantInput = $('[name="id"]', form);
    var priceElement = $('[data-product-price]', root);
    var inventoryElement = $('[data-inventory-note]', root);
    var addButton = $('[data-add-to-cart]', form);
    var stickyPrice = $('[data-sticky-price]', root);
    var stickyButton = $('[data-sticky-add]', root);
    var featuredImage = $('[data-featured-image]', root);
    var variantImagesElement = $('[data-variant-images]', root);
    var variantImages = {};
    try { variantImages = variantImagesElement ? JSON.parse(variantImagesElement.textContent) : {}; }
    catch (error) { variantImages = {}; }

    function selectedVariant() {
      if (variants.length === 1) return variants[0];
      var selected = {};
      $$('[data-option-input]:checked', root).forEach(function (input) { selected[input.dataset.optionIndex] = input.value; });
      $$('[data-option-select]', root).forEach(function (select) { selected[select.dataset.optionIndex] = select.value; });
      return variants.find(function (variant) {
        return variant.options.every(function (option, index) { return selected[index] === option; });
      });
    }

    function updateVariant() {
      var variant = selectedVariant();
      if (!variant) return;
      if (variantInput) variantInput.value = variant.id;
      if (priceElement) priceElement.innerHTML = formatMoney(variant.price) + (variant.compare_at_price && variant.compare_at_price > variant.price ? ' <s>' + formatMoney(variant.compare_at_price) + '</s>' : '');
      if (addButton) {
        addButton.disabled = !variant.available;
        addButton.textContent = variant.available ? (addButton.dataset.addText || 'Add to cart') : 'Sold out';
      }
      if (stickyPrice) stickyPrice.textContent = formatMoney(variant.price);
      if (stickyButton) stickyButton.disabled = !variant.available;
      if (inventoryElement) {
        inventoryElement.hidden = false;
        inventoryElement.className = 'inventory-note';
        if (!variant.available) {
          inventoryElement.textContent = inventoryElement.dataset.soldout || 'Sold out';
          inventoryElement.classList.add('inventory-note--out');
        } else if (variant.inventory_management && typeof variant.inventory_quantity === 'number' && variant.inventory_quantity > 0 && variant.inventory_quantity <= 5) {
          inventoryElement.textContent = (inventoryElement.dataset.low || 'Only a few left') + ' (' + variant.inventory_quantity + ')';
          inventoryElement.classList.add('inventory-note--low');
        } else inventoryElement.textContent = inventoryElement.dataset.instock || 'In stock';
      }
      if (variantImages[variant.id] && featuredImage) featuredImage.src = variantImages[variant.id];
      root.dispatchEvent(new CustomEvent('product:variant-change', { bubbles: true, detail: { variant: variant } }));
    }

    root.addEventListener('change', function (event) {
      if (event.target.matches('[data-option-input], [data-option-select]')) updateVariant();
    });
    updateVariant();
  });

  /* ---------- Product thumbnails ---------- */
  $$('[data-thumbs]').forEach(function (thumbs) {
    var root = thumbs.closest('[data-product-root]') || document;
    var featured = $('[data-featured-image]', root);
    thumbs.addEventListener('click', function (event) {
      var button = event.target.closest('[data-thumb]');
      if (!button || !featured) return;
      if (button.dataset.full) featured.src = button.dataset.full;
      var thumbnailImage = button.querySelector('img');
      if (thumbnailImage) featured.alt = thumbnailImage.alt;
      $$('[data-thumb]', thumbs).forEach(function (thumbnail) { thumbnail.setAttribute('aria-current', thumbnail === button ? 'true' : 'false'); });
    });
  });

  /* ---------- Initial cart state ---------- */
  refreshCart(false).catch(function () { /* Cart page may be unavailable during editor preview. */ });
})();
