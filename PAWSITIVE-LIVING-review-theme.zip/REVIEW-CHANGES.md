# PAWSITIVE.LIVING — review build change log

## Theme functionality

`assets/theme.js` was rebuilt to replace the broken four-character stub. It restores the theme's core interactions and adds defensive request handling. The new implementation uses the native Shopify AJAX cart endpoints and does not add third-party dependencies.

## Quiz safety and logic

A pet-care safety question now appears before the product-discovery questions. If the shopper selects that a pet has a current skin condition, open wound, known ingredient sensitivity, ongoing veterinary treatment, or the shopper is unsure, the quiz stops immediately and recommends speaking with a veterinarian. It does not request details or generate a product recommendation in that path. When a normal result is appropriate, a tie between product scores resolves to the bundle.

## Claims and trust

The theme no longer displays the unverified fixed-dollar-per-order promise. Amount display is off by default, partner copy remains neutral until confirmed, and FAQ/product/footer defaults describe the program as in development. The reviews section remains hidden unless real review blocks are added.

## Hero video

The supplied 8-second 960 × 540 H.264 MP4 is retained at `assets/hero-video.mp4` and enabled in the homepage configuration. Autoplay is muted, looping, and inline. A reduced-motion preference pauses the video.

## Packaging and deployment status

This is a **review-only ZIP**. The Shopify theme folder structure is at the ZIP root for theme upload. Upload it as an unpublished theme and test it in the Theme Editor. No changes were pushed to GitHub and no live theme was altered or published. Do not publish until the preview checklist is complete and the changes are approved.
