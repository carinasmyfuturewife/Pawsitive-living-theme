# PAWSITIVE.LIVING Shopify theme — review build

This is an unpublished review package for the PAWSITIVE.LIVING storefront.

1. In Shopify Admin, open **Online Store → Themes**.
2. Select **Add theme → Upload zip file** and upload this ZIP.
3. Preview the uploaded theme from Theme library; do not publish it as part of review.
4. Complete the checklist in `TESTING.md` before approving publication.

The ZIP contains Shopify theme directories (`assets/`, `config/`, `layout/`, `locales/`, `sections/`, `snippets/`, and `templates/`) at its root. `REVIEW-CHANGES.md` describes the implementation pass.

No GitHub push, live-theme edit, or publication was performed as part of this package preparation.
